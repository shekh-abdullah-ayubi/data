
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from joblib import dump
from pathlib import Path

Path("models").mkdir(exist_ok=True)

train_df = pd.DataFrame({
    "text": [
        "prior authorization required for Humira",
        "step therapy needed for Enbrel",
        "coverage approved for Adalimumab"
    ],
    "label": [
        "PA_REQUIRED",
        "STEP_THERAPY",
        "APPROVED"
    ]
})

pipeline = Pipeline([
    ("tfidf", TfidfVectorizer()),
    ("clf", LogisticRegression())
])

pipeline.fit(train_df["text"], train_df["label"])

dump(pipeline, "models/extractor.joblib")

print("Model trained and saved.")
