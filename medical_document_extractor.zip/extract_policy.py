
import fitz
import re

def extract_policy_entities(pdf_path):
    doc = fitz.open(pdf_path)

    text = ""
    for page in doc:
        text += page.get_text()

    extracted = []

    drug_matches = re.findall(r'(Humira|Adalimumab|Enbrel)', text, re.IGNORECASE)

    pa_required = bool(re.search(r'prior authorization', text, re.IGNORECASE))
    step_therapy = bool(re.search(r'step therapy', text, re.IGNORECASE))

    for drug in drug_matches:
        extracted.append({
            "drug_name": drug,
            "prior_authorization": pa_required,
            "step_therapy": step_therapy
        })

    return extracted
