
import pdfplumber
import pandas as pd

def extract_formulary_tables(pdf_path):
    extracted_rows = []

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            tables = page.extract_tables()

            for table in tables:
                for row in table[1:]:
                    if row and len(row) >= 3:
                        extracted_rows.append({
                            "drug_name": row[0],
                            "tier": row[1],
                            "quantity_limit": row[2]
                        })

    return pd.DataFrame(extracted_rows)
