
import json
from pathlib import Path
from joblib import load

from extract_policy import extract_policy_entities
from drug_mapper import normalize_drug_name

model = load("models/extractor.joblib")

sample_policy = "sample_data/policy_pdfs/sample_policy.pdf"

results = extract_policy_entities(sample_policy)

final_results = []

for row in results:
    normalized = normalize_drug_name(row["drug_name"])

    prediction = model.predict([
        f"{normalized} prior authorization"
    ])[0]

    final_results.append({
        "drug_name": normalized,
        "prediction": prediction,
        "details": row
    })

Path("output").mkdir(exist_ok=True)

with open("output/results.json", "w") as f:
    json.dump(final_results, f, indent=2)

print("Extraction completed.")
