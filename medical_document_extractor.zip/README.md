
# Medical Document Extraction Pipeline

This project demonstrates a hybrid extraction pipeline for:

- Formulary PDF extraction (table-based)
- Policy PDF extraction (NLP/rule-based)
- Drug mapping
- Structured output storage
- Model persistence using joblib

## Features

- PDF parsing
- Table extraction
- NLP entity extraction
- Drug matching
- Structured JSON output
- Trainable extraction pipeline
- Save/load model

## Run

```bash
pip install -r requirements.txt
python train_model.py
python run_extraction.py
```
