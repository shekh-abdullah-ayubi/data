
FORMULARY_PDF_FOLDER = "sample_data/formulary_pdfs"
POLICY_PDF_FOLDER = "sample_data/policy_pdfs"

MODEL_PATH = "models/extractor.joblib"
OUTPUT_PATH = "output/results.json"
