
from rapidfuzz import fuzz

CANONICAL_DRUGS = {
    "Humira": "Adalimumab",
    "Enbrel": "Etanercept"
}

def normalize_drug_name(drug):
    for brand, generic in CANONICAL_DRUGS.items():
        if fuzz.ratio(drug.lower(), brand.lower()) > 80:
            return generic

        if fuzz.ratio(drug.lower(), generic.lower()) > 80:
            return generic

    return drug
